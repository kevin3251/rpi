const express = require('express')
const Datastore = require('nedb')
const app = express()

const bodyParser = require('body-parser');
const path = require('path')
const db = new Datastore({
    filename: path.join('./', 'health.db')
})
db.loadDatabase()

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('./'))

app.post('/store', (req, res) => {
    let data = req.body
    db.insert(data, (err, newDoc) => {
        console.log('err  :  ', err)
        console.log('doc  :  ', newDoc)
    })
    res.json(data)
})

app.post('/query', (req, res) => {
    db.find(req.body, (err, docs) => {
        console.log('err  :  ', err)
        console.log('docs  :  ', docs)
        res.json(docs)
    })
})

app.listen(3000, function () {
    console.log('app listening on port 3000!')
})

