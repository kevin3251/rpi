const mqtt = require('mqtt');
const BufferList = require('bl');
const DataView = require('buffer-dataview');
const hookline = require('hookline');

const btleAdapter = require('../lib/btleAdapter');

function bufToSfloat(buf) {
    let dv = new DataView(buf);
    let data = dv.getUint16(0, true);
    let mantissa = (data & 0x0FFF);
    if ((mantissa & 0x0800) > 0) {
        mantissa = -1 * (~(mantissa - 0x01) & 0x0FFF);
    }
    let exponential = data >> 12;
    return mantissa * Math.pow(10, exponential);
}

let ecgOption = {
    target: 'GSH_ECG',
    targetType: 'name',
    trigger: function (error, conn) {
        if (error) {
            console.log('error : ', error);
            return;
        }

        let bl = new BufferList();

        conn.on('destroy', function () {
            console.log('disconnect');
              let client = mqtt.connect('mqtt://127.0.0.1:1883');
              client.on('connect', function () {
                 //client.publish('ECG', bl.slice(0));
                 client.publish('ECG', 'testing');
                 client.end();
             })
        })

        conn.write('fff0', 'fff4', new Buffer([0xB0]));
        conn.subscribe('fff0', 'fff3', data => {
            bl.append(data);
        });


    }
};

let bloodOption = {
    target: 'd8:63:09:fa:ad:72',
    targetType: 'address',
    trigger: function (error, conn) {
        if (error) {
            console.log(error);
            return;
        }
        conn.subscribe('1810', '2a36', data => {
            console.log('2a36 subscribe');
        });

        conn.subscribe('1810', '2a35', data => {
            console.log('2a35 subscribe');
            let flags = data.slice(0, 1).readUInt8();
            let bloodPressureUnitsFlag = flags & 0b10000000;
            let timeStampFlag = flags & 0b01000000;
            let pulseRateFlag = flags & 0b00100000;
            let userIdFlag = flags & 0b00010000;
            let measurementStatusFlag = flags & 0b00001000;

            function getSystolic() {
                let unit = bloodPressureUnitsFlag ? 'kPa' : 'mmHg';
                return bufToSfloat(data.slice(1, 3)) + ' ' + unit;
            }

            function getDiastolic() {
                let unit = bloodPressureUnitsFlag ? 'kPa' : 'mmHg';
                return bufToSfloat(data.slice(3, 5)) + ' ' + unit;
            }

            function getPulseRate() {
                return pulseRateFlag ? bufToSfloat(data.slice(14, 16)) : '';
            }

            function getMeanArterialPressure() {
                return bufToSfloat(data.slice(5, 7));
            }

            function getUserID() {
                return userIdFlag ? data.slice(16, 17).readUInt8() : '';
            }

            function getMeasurementStatus() {
                return measurementStatusFlag ? data.slice(17).readUInt16LE() : '';
            }

            function getTimeStamp() {
                let timeStampBuf = data.slice(7, 14);
                let timeStamp = '';
                if (!timeStampFlag) {
                    let year = timeStampBuf.slice(0, 2).readUInt16LE() + '-';
                    let month = timeStampBuf.slice(2, 3).readUInt8() + '-';
                    let day = timeStampBuf.slice(3, 4).readUInt8() + '-';
                    let hour = timeStampBuf.slice(4, 5).readUInt8() + ':';
                    let minute = timeStampBuf.slice(5, 6).readUInt8() + ':';
                    let second = timeStampBuf.slice(6).readUInt8();
                    timeStamp = timeStamp + year + month + day + hour + minute + second;
                }
                return timeStamp;
            }

            

            let client = mqtt.connect('mqtt://127.0.0.1:1883');
            client.on('connect', function () {
                let data = {
                    systolic: getSystolic(),
                    diastolic: getDiastolic(),
                    pulseRate: getPulseRate(),
                    meanArterialPressure: getMeanArterialPressure(),
                    userID: getUserID(),
                    measurementStatus: getMeasurementStatus(),
                    timeStamp: getTimeStamp()
                }
                console.log(JSON.stringify(data));
                client.publish('BloodPressure', JSON.stringify(data));
                client.end();
            })
        });
    }
};

hookline.on('data', data => {
    let client = mqtt.connect('mqtt://127.0.0.1:1883');
    client.on('connect', function () {
        console.log(data)
        client.publish('NFC', data);
        client.end();
    });
});

hookline.start();
btleAdapter.addRequest(ecgOption);
btleAdapter.addRequest(bloodOption);